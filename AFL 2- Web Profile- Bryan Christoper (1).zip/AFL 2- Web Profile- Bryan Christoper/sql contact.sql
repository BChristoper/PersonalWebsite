CREATE DATABASE IF NOT EXISTS contact;

USE contact;

CREATE TABLE Contact (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(100),
    email VARCHAR(100),
    subjek VARCHAR(255),
    pesan TEXT
);